var demo = new Vue({
  el: '#demo',
  data: {
    message: 'Hello from Vue.js!'
  }
})